Trailer
=======

Copyright (c) 2013-2014 HouseTrip Ltd. Released under the terms of the MIT licence, see the file LICENCE for details.

For maintained binaries and/or more info:

- [Official OSX build](http://dev.housetrip.com/trailer/)

- [Official iOS build](https://itunes.apple.com/US/app/id806104975?mt=8)
